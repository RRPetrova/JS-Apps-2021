import page from '../node_modules/page/page.mjs';
import { render } from '../node_modules/lit-html/lit-html.js';

const main = document.querySelector('main');

page('/', () => console.log('home page'));

page.start();